package com.crownzone.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyBox: EditText
    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }

    private fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; setOnClickListener { f() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32)
            setBackgroundColor(Color.parseColor("#0B1020"))
        }
        root.addView(TextView(this).apply { text = "J.A.R.V.I.S."; textSize = 26f; setTextColor(Color.parseColor("#4FC3F7")) })
        root.addView(TextView(this).apply {
            text = "1) Erişilebilirliği aç ve JARVIS'i etkinleştir\n2) Mikrofon izni ver\n3) Ekranda çıkan 🎤 butonuna dokun ve konuş"
            textSize = 13f; setTextColor(Color.LTGRAY)
        })
        root.addView(btn("1) Erişilebilirlik ayarlarını aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2) Mikrofon izni ver") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) })
        keyBox = EditText(this).apply {
            hint = "Groq API anahtarı (sohbet ve ekran anlatma için, isteğe bağlı)"
            setText(prefs.getString("key", "")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 13f
        }
        root.addView(keyBox)
        root.addView(btn("Anahtarı kaydet") { prefs.edit().putString("key", keyBox.text.toString().trim()).apply() })
        logView = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE) }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val input = EditText(this).apply { hint = "Komut yaz..."; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(input)
        root.addView(btn("Gönder") {
            val t = input.text.toString(); input.setText("")
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            Brain.get(this).handle(t)
        })
        setContentView(root)
        Brain.get(this).onLog = { s -> runOnUiThread { logView.append(s + "\n"); scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    }

    override fun onPause() {
        prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
        super.onPause()
    }
}
