package com.crownzone.jarvis

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Brain private constructor(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Brain? = null
        fun get(c: Context): Brain = inst ?: synchronized(this) {
            inst ?: Brain(c.applicationContext).also { inst = it }
        }
    }

    private val tr = Locale("tr", "TR")
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    var onLog: ((String) -> Unit)? = null

    init { tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts.language = tr } }

    fun stopSpeaking() { tts.stop() }

    fun say(t: String) {
        onLog?.invoke("JARVIS: $t")
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    private fun norm(s: String) = s.lowercase(tr)
        .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
        .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
        .filter { it.isLetterOrDigit() }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) { say("Açılamadı.") }
    }

    private fun act(s: JarvisService?, f: (JarvisService) -> Boolean) {
        if (s == null) say("Önce erişilebilirlik iznini aç.") else if (!f(s)) say("Yapamadım.")
    }

    fun handle(raw: String?) {
        val t = raw?.trim().orEmpty()
        if (t.isEmpty()) return
        onLog?.invoke("Sen: $t")
        val l = t.lowercase(tr).replace("'", " ").replace("’", " ").trim()
        val s = JarvisService.instance

        Regex("^(mesaj )?yaz\\s+(.+)$").find(l)?.let { m ->
            val txt = t.substring(m.groups[2]!!.range.first)
            if (s == null) say("Önce erişilebilirlik iznini aç.")
            else say(if (s.typeText(txt)) "Yazdım." else "Yazı alanı bulamadım.")
            return
        }
        val click = Regex("^(?:(?:tıkla|dokun|bas)\\s+(.+)|(.+?)\\s+(?:tıkla|dokun|bas))$").find(l)
        val open = Regex("^(.+?)\\s*(aç|açar mısın|açsana|başlat|çalıştır)$").find(l)

        when {
            l == "gönder" || l == "gönder bas" -> act(s) { it.clickByText("Gönder") || it.clickByText("Send") }
            l.startsWith("geri") -> act(s) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }
            l.startsWith("ana ekran") || l.startsWith("ana sayfa") -> act(s) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }
            l.startsWith("son uygulama") -> act(s) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            l.startsWith("bildirim") -> act(s) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
            l.contains("aşağı kaydır") -> act(s) { it.scroll(true) }
            l.contains("yukarı kaydır") -> act(s) { it.scroll(false) }
            l.contains("ekranı oku") || l.contains("ekranda ne var") || l.contains("ekranı izle") || l.contains("ekranı anlat") -> readScreen(s)
            l.contains("fotoğraf çek") || l.contains("resim çek") || l.contains("fotoğraf yap") -> photo(s)
            l.contains("saat kaç") -> say("Saat " + SimpleDateFormat("HH:mm", tr).format(Date()))
            l == "sus" || l == "dur" || l == "durdur" -> tts.stop()
            l.startsWith("ara ") || l.startsWith("araştır ") ->
                start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, t.substringAfter(" ")))
            click != null -> {
                val label = click.groups[1]?.value ?: click.groups[2]!!.value
                act(s) { it.clickByText(label) }
            }
            open != null -> openApp(open.groupValues[1])
            else -> ask(t)
        }
    }

    private fun openApp(name: String) {
        val skip = setOf("uygulamasını", "uygulamayı", "uygulaması", "uygulama", "ı", "i", "u", "ü")
        val q = norm(name.split(" ").filter { it !in skip }.joinToString(""))
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == q }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) }
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (intent == null) say("$name uygulamasını bulamadım.") else { say("$name açılıyor."); start(intent) }
    }

    private fun photo(s: JarvisService?) {
        say("Kamera açılıyor.")
        start(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        if (s != null) main.postDelayed({
            listOf("Deklanşör", "Fotoğraf çek", "Shutter", "Capture").any { s.clickByText(it) }
        }, 2500)
    }

    private fun readScreen(s: JarvisService?) {
        if (s == null) { say("Önce erişilebilirlik iznini aç."); return }
        val txt = s.readScreen()
        if (txt.isBlank()) { say("Ekranda okunabilir bir şey bulamadım."); return }
        ask("Telefon ekranındaki metinler: " + txt.take(5000) + "\nBu ekranda ne olduğunu kısaca anlat.", txt.take(400))
    }

    private fun ask(prompt: String, fallback: String? = null) {
        val key = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("key", "")?.trim().orEmpty()
        if (key.isEmpty()) { say(fallback ?: "Bunu anlayamadım. Sohbet için uygulamaya Groq anahtarı gir."); return }
        Thread {
            val reply = try {
                val c = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.setRequestProperty("Authorization", "Bearer $key")
                c.setRequestProperty("Content-Type", "application/json")
                c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
                val body = JSONObject().put("model", "llama-3.1-8b-instant").put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "Sen JARVIS adlı, kısa ve net konuşan Türkçe sesli asistansın. En fazla 3 cümle yaz."))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                if (ok) JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                else "Yapay zeka hatası: ${c.responseCode}"
            } catch (e: Exception) { "Bağlantı hatası." }
            main.post { say(reply) }
        }.start()
    }
}
